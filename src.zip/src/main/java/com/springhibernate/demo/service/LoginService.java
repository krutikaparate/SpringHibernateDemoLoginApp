package com.springhibernate.demo.service;

public interface LoginService{    
       public boolean checkLogin(String userName, String userPassword);
}
