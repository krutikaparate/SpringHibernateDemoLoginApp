package com.springhibernate.demo.dao;

public interface LoginDAO{    
       public boolean checkLogin(String userName, String userPassword);
}
